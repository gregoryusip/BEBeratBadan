<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>

    <div class="container">


        <h1 class="mt-5">ALL DATA</h1>

        <a href="/create"><button type="button" class="btn btn-outline-secondary mt-5 mr-3">Add Data</button></a>

        <table class="table table-hover mt-5">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">Tanggal</th>
                    <th scope="col">Max</th>
                    <th scope="col">Min</th>
                    <th scope="col">Perbedaan</th>
                    <th scope="col"></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $weightData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"> <a href="<?php echo e(url('detail/'.$data->id)); ?>">  <?php echo e($data->tanggal); ?> </a> </th>
                        <td><?php echo e($data->maxi); ?></td>
                        <td><?php echo e($data->mini); ?></td>
                        <td><?php echo e($data->perbedaan); ?></td>
                        <td>
                            <a href="<?php echo e(url('edit/'.$data->id)); ?>"><button type="button" class="btn btn-outline-secondary">Edit Data</button></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <th scope="row">RATA-RATA</th>
                    <td> <?php echo e(round($avgMax, 1)); ?></td>
                    <td> <?php echo e(round($avgMin, 1)); ?></td>
                    <td> <?php echo e(round($avgPerbedaan, 1)); ?></td>
                </tr>
            </tbody>
        </table>
    </div>

</body>
</html>
<?php /**PATH C:\IPE\WEBSITE\WEBSITE\sirclo_beratBadan\resources\views/index.blade.php ENDPATH**/ ?>